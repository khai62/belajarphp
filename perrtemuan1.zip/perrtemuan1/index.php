<?php

echo "khairuddin";

?>
<?php

//  echo date("j, n, Y");

// jika ingin tau 365 hari ke depan klau ke belakang tinggal + di ganti -

echo  date("l", time()+60*60*24*365), "<br/>";




// mktime 
// membuat sendiri detik 
// mktime(0,0,0,0,0,0) 
// jam, menit detik, bulan, tanggal, tahun 

echo date("l", mktime(0,0,0,8,6,2003))

?>
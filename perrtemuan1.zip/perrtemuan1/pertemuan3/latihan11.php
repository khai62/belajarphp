<?php

// pengkondisian 
// if else  // if else if else 
$x = 8;

if($x < 5){
    echo "kamu pasi bisa coba lagi";
}else if($x ==  5){
    echo "semangat";
}else{
    echo "kamu hebat";
}

echo "<br>";
// ternery 
 $a = 10 > 11 ? "kamu pasti bisa" : "kamu hebat";
 echo "$a";

echo "<br>";

// switch 
$y = 0;
switch($y){
    case 1:
        echo "nila anda 1 dari $y";
        break;
    case 2:
        echo "nila anda 2 dari $y";
        break;
    case 3:
        echo "nila anda 3 dari $y";
        break;
    case 4:
        echo "nila anda 4 dari $y";
        break;
    case 5:
        echo "nila anda 5 dari $y";
        break;
    default:
        echo "tidak ada nilai";
}
?>
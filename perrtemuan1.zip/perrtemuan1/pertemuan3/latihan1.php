<?php
// perulangan 
// for 

for ($i = 0; $i < 5; $i++){
    echo "$i  khairuddin kamu pasi bisa <br>";
};
// while 
$j  = 0;
while($j < 5){
    echo "$j  khairuddin kamu orang hebat <br>";
    $j++;
}
// do while 
$x = 0;

do{
    echo "$x  khairuddin kamu akan menjadi orang berpengaruh <br>";
    $x++;
}while($x < 5);
// foreach : perulangan khusus untuk array 
?>
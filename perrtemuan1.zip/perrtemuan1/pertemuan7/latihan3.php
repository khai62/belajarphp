<?php 
// nyambung ke latihan 4 
$mahasiswa = [
    [
        "Nama" => "khai",
         "NPM" => "221510062",
          "Prodi" => "teknik", 
          "Email" => "khai@email.com",
          "gambar" => "gambar1.jpeg"
        ],
    [
        "Nama" => "khairuddin",
         "NPM" => "221510063", 
         "Prodi" => "sistem informasi", 
         "Email" => "uddin@email.com",
         "gambar" => "gambar2.jpeg",
         "tugas" => [10, 20, 30]
        ],
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GET</title>
</head>
<body>
    <h2>Daftar Mahasiswa</h2>
    <ul>
        <?php foreach($mahasiswa as $values) : ?>
            <li>
                <a href="latihan4.php?nama=<?= $values["Nama"]; ?>&npm=<?= $values["NPM"]; ?>&prodi=<?= $values["Prodi"]; ?>&email=<?= $values["Email"]; ?>&gambar=<?= $values["gambar"]; ?>"><?= $values["Nama"]; ?></a>
            </li>
        <?php endforeach ?>
    </ul>

</body>
</html>
<!-- myambung ke latihan 6  -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POST</title>
</head>
<body>
    <form action="latihan6.php", method="post">
        Masukkan nama:
        <input type="text" name="nama">
        <br>
        <button type="submit" name="submin">kirim</button>
    </form>
    
</body>
</html>
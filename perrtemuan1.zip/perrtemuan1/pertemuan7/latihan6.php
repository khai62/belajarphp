<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>nyambung ke latihan5</title>
</head>
<body>
    <h1>selamat datang, <?= $_POST["nama"] ?></h1>
</body>
</html>
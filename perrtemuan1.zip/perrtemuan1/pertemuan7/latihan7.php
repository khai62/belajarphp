<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POST</title>
</head>
<body>
    <?php if(isset($_POST["submit"])) : ?>
    <h2>selamat datang, <?= $_POST["nama"] ?></h2>
    <?php endif ?>
    <form action="", method="post">
        Masukkan nama:
        <input type="text" name="nama">
        <br>
        <button type="submit" name="submit">kirim</button>
    </form>
    
</body>
</html>
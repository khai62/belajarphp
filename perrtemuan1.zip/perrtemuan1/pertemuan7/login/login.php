<?php 

if(isset($_POST["submit"])){
    if($_POST["username"] == "khai" && $_POST["password"] == "123"){
        header("Location: admin.php");
        exit;
    }else{
        $error = true;
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php if(isset($error)) : ?>
        <p style="color : red", font-style: italic>username atau password salah</p>
    <?php endif; ?>

    <ul>
    <h1>Login </h1>
    <form action="" method="post">
        <li>
            <label for="menghubungkalabeldenganinput">Username</label>
            <input type="text" name="username" id="menghubungkalabeldenganinput">
        </li>
        <li>
            <label for="password">Password</label>
            <input type="password" name="password" id="password">
        </li>
        <li>
            <Button type="submit" name="submit">Login</Button>
        </li>
    </form>
    </ul>
</body>
</html>
<?php 
// superGlobal 
// variabel global milik php 
// merupakan array asosiatif 
// $_GET
// $_POST
// $_REQUEST
// $_SESSION
// $_COOKIE
// $_SERVER
// $_ENV

?>
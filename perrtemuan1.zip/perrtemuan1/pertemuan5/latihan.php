
<!-- array numarik  -->
<?php 
$mahasiswa = [
    ["khai", "221510062", "teknik", "khai@email.com"],
    ["khairuddin", "221510062", "si", "rudin@email.com"],
    ["muhammad", "221510062", "PAI", "muhammad@email.com"],
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Mahasiswa</h2>
        <?php foreach($mahasiswa as $values) :?>
            <ul>
                <?php foreach($values as $value) : ?>
                <li><?= $value ?></li>
                <?php endforeach ?>
            </ul>
        <?php endforeach; ?>
</body>
</html>
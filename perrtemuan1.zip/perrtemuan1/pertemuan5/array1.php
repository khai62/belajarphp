<?php

$angka = [1,2,3,4,5,6,7];
 ?>

 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
 </head>
 <style>
    .kotak{
        width: 50px;
        height: 50px;
        background: salmon;
        text-align: center;
        line-hight: 50px;
        margin : 3px;
        float: left;
    }
    .clear{
        clear: both;
    }
 </style>
 <body>
    <!-- menggunakan for  -->
    <?php for($i = 0; $i < count($angka); $i++) :?>
    <div class="kotak">
        <?php echo $angka[$i]; ?>
    </div>
    <?php endfor ?>
    <!-- akhir for  -->
    <div class="clear"></div>


    <!-- menggunakan foreach  -->
     <?php foreach($angka as $value) : ?>
        <div class="kotak"><?= echo $value ?></div>
    <?php endforeach?>
    <!-- akhir dari foreach  -->
 </body>
 </html>

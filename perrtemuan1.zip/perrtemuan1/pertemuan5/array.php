<?php 
// array 
$hari = ["senin", "selasa", "rabu", "kamis"];






// menambahkan elemen pada araray 
$hari[] = "jumat";

// menampilkan array 
var_dump($hari);
echo "<br/>";
print_r($hari);
echo "<br/>";
echo $hari[1];
?>
<?php 

$conn = mysqli_connect("localhost", "root", "", "phpdasar");


function query($query){
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while($row = mysqli_fetch_assoc($result)){
        $rows[] = $row;
    }
    return $rows;
}

// fungsi tambah data 
function tambah($data){
    global $conn;

    $nama = htmlspecialchars($data["nama"]);
    $npm = htmlspecialchars($data["npm"]);
    $email = htmlspecialchars($data["email"]);
    $jurusan = htmlspecialchars($data["jurusan"]);

    $gambar = upload();
    if(!$gambar){
        return false;
    }

    $query = "INSERT INTO mahasiswa VALUES('','$nama','$npm','$email','$jurusan','$gambar')";

    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}

function upload(){
    $namaFile = $_FILES['gambar']['name'];
    $ukuranFile = $_FILES['gambar']['size'];
    $error = $_FILES['gambar']['error'];
    $tmpName = $_FILES['gambar']['tmp_name'];

    // cek jika tidak upload foto 
    if($error === 4){
        echo "<script>
            alert('gambar tidak boleh kosong');
        </script>";
    }

    // cek apakah gambar yang di upload adalah gambar 
    $extensiGambarValit = ['jpg', 'jpeg', 'png'];
    $extensiGambar = explode('.', $namaFile);
    $extensiGambar = strtolower(end($extensiGambar));
    if(!in_array($extensiGambar, $extensiGambarValit)){
        echo "<script>
            alert('pastikan yang anda upload gambar adalah!!');
        </script>";
    }

    // cek jika gambar terlalu besar 
    if($ukuranFile > 2000000){
        echo "<script>
            alert('gambar tidak boleh lebih dari 1 mb!!');
        </script>";
    }

    // lolos pengecekan gambar siap di upload 
    // genetet nama baru agar tidak ada nama gambar yang sama 
    $namaFileBaru = uniqid();
    $namaFileBaru .= '.';
    $namaFileBaru .= $extensiGambar;
    move_uploaded_file($tmpName, 'img/' . $namaFileBaru);
    return $namaFileBaru;
}

function hapus($id){


    global $conn;
    $file = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM mahasiswa WHERE id= $id "));
    unlink('img/' . $file["gambar"]);
    $hapus = "DELETE FROM mahasiswa WHERE id= $id ";
    mysqli_query($conn, $hapus);
    return mysqli_affected_rows($conn);
}

function ubah($data){
    global $conn;
    $id = $data["id"];
    $nama = htmlspecialchars($data["nama"]);
    $npm = htmlspecialchars($data["npm"]);
    $email = htmlspecialchars($data["email"]);
    $jurusan = htmlspecialchars($data["jurusan"]);
    $gambarLama = htmlspecialchars($data["gambarLama"]);

    // cek apakah user pilih gambar baru atau tidak 
    if($_FILES['gambar']['error'] === 4){
        $gambar = $gambarLama;
    }else{
        $gambar = upload();
    }
    

    $query = "UPDATE mahasiswa SET nama= '$nama', npm= '$npm', email= '$email', jurusan= '$jurusan', gambar= '$gambar' WHERE id= $id ";

    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}

function cari($keyword){
    $query = "SELECT * FROM mahasiswa WHERE nama LIKE '%$keyword%' OR npm LIKE '%$keyword%' OR jurusan LIKE '%$keyword%'";
    return query($query);
}

function registersi($data){
    global $conn;

    $username = strtolower(stripslashes($data["username"]));
    $password = mysqli_real_escape_string($conn, $data["password"]);
    $password2 = mysqli_real_escape_string($conn, $data["password2"]);

    // cek username udah ada atau blm 
    $result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username'");
    if(mysqli_fetch_assoc($result)){
        echo "<script>
        alert('username sudah terdaftar')
    </script>";
    return false;
    }

    // cek konfirmasi password 
    if($password !== $password2){
        echo "<script>
            alert('password harus sama')
        </script>";
        return false;
    }

    // enkripsi password 
    $password = password_hash($password, PASSWORD_DEFAULT);
    // tambahkan user ke database 
    mysqli_query($conn, "INSERT INTO user VALUES('', '$username', '$password')");
    return mysqli_affected_rows($conn);
}

?>
<?php  

// di phap ada standar output 
// echo 
// print_r 
// var_dumo 


// penulisan sintac php ada 2 
// php di dalam html 
// html di dalam php 


// variabel 
// $nama = "khairuddin";
// echo "nama saya $nama";

// operator penggabung string 
$nama_depan = "khai";
$nama_belakang = "ruddin";

echo $nama_depan . $nama_belakang;

 ?>
<?php 
// Array asosiatif 
$mahasiswa = [
    [
        "Nama" => "khai",
         "NPM" => "221510062",
          "Prodi" => "teknik", 
          "Email" => "khai@email.com",
          "gambar" => "gambar1.jpeg"
        ],
    [
        "Nama" => "khairuddin",
         "NPM" => "221510063", 
         "Prodi" => "sistem informasi", 
         "Email" => "uddin@email.com",
         "gambar" => "gambar2.jpeg",
         "tugas" => [10, 20, 30]
        ],
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Mahasiswa</h2>
    <?php foreach($mahasiswa as $values) : ?>
        <ul>
            <li>
                <img src="img/<?= $values["gambar"] ?>" width=100, height=100 />
            </li>
            <li>Nama : <?= $values["Nama"] ?></li>
            <li>Npm : <?= $values["NPM"] ?></li>
            <li>Prodi : <?= $values["Prodi"] ?></li>
            <li>Email : <?= $values["Email"] ?></li>
            <?php if(isset($values["tugas"])) : ?>
                <?php foreach($values["tugas"] as $value) : ?>
                    <ul>
                        <li>Tugas : <?= $value ?></li>
                    </ul>
                <?php endforeach; ?>
            <?php endif; ?>
        </ul>
    <?php endforeach; ?>
</body>
</html>
